import os

files = os.listdir('./static/download')
print(files)