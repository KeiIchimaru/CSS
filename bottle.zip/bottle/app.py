 # -*- coding: utf-8 -*-

from bottle import run, route, template, get, post, request, static_file, install
import os

# conda activate
HOST='192.168.10.28'

# 静的ファイル
@route('/img/<file_path:path>')
def staticFileImg(file_path):
    return static_file(file_path, root='./static/img/')

@route('/css/<file_path:path>')
def staticFileCss(file_path):
    return static_file(file_path, root='./static/css/')

@route('/js/<file_path:path>')
def staticFileJs(file_path):
    return static_file(file_path, root='./static/js/')

# download
@route('/download')
def download():
    files = os.listdir('./static/download')
    return template('download', files=files)

@route('/download/<file_path:path>')
def staticFileDownload(file_path):
    return static_file(file_path, root='./static/download/', download=True)

# run
if __name__ == '__main__':
    run(host=HOST, port=8080, debug=True, reloader=True)