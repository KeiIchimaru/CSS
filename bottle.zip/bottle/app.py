 # -*- coding: utf-8 -*-
import sys
import os
# bottle.py, waitressのPATH設定
BASE_PATH = os.path.dirname(os.path.realpath(__file__))
STATIC_PATH = os.path.join(BASE_PATH, 'static')
VIEWS_PATH = os.path.join(BASE_PATH, 'views')
ROOT_IMG = os.path.join(STATIC_PATH, 'img')
ROOT_CSS = os.path.join(STATIC_PATH, 'css')
ROOT_JS = os.path.join(STATIC_PATH, 'js')
ROOT_DOWNLOAD = os.path.join(STATIC_PATH, 'download')

sys.path.append(os.path.join(BASE_PATH, 'libs'))

from bottle import Bottle, TEMPLATE_PATH, run, route, template, static_file
from waitress import serve  # Waitressをインポート

app = Bottle()

# conda activate
HOST='192.168.10.21'

# 静的ファイル
@app.route('/img/<file_path:path>')
def staticFileImg(file_path):
    return static_file(file_path, root=ROOT_IMG)

@app.route('/css/<file_path:path>')
def staticFileCss(file_path):
    return static_file(file_path, root=ROOT_CSS)

@app.route('/js/<file_path:path>')
def staticFileJs(file_path):
    return static_file(file_path, root=ROOT_JS)

# download
@app.route('/download')
def download():
    files = os.listdir(ROOT_DOWNLOAD)
    return template('download', files=files)

@app.route('/download/<file_path:path>')
def staticFileDownload(file_path):
    return static_file(file_path, root=ROOT_DOWNLOAD, download=True)

# run
if __name__ == '__main__':
    # run(server="waitress", host=HOST, port=8080, debug=True, reloader=True)
    TEMPLATE_PATH.insert(0, VIEWS_PATH)  
    serve(app, host=HOST, port=8080, threads=10)