import pyxel
from block import Block

# V0.1 ブロックを表示する

# ゲーム画面設定
FPS = 30
WINDOW_WIDTH = 160
WINDOW_HIGHT = 120

class App:
    def __init__(self):
        pyxel.init(WINDOW_WIDTH, WINDOW_HIGHT, title="ブロック崩し", fps=FPS)
        self.blocks = []
        self.blocks.append(Block(10, 10, 20, 5, 2))
        self.blocks.append(Block(10, 20, 20, 5, 3))
        self.blocks.append(Block(10, 30, 20, 5, 4))
        pyxel.run(self.update, self.draw)    

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()

    def draw(self):
        pyxel.cls(0)
        for b in self.blocks:
            b.draw()

App()