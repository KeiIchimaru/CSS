import pyxel
from block import Block
from ball5 import Ball

# V2 ブロックとの衝突チェック追加

BLOCK_MARGIN = 1
SOUND_CHANNEL = 1
SOUND_BLOCK = 2

class BlockManager:
    def __init__(self, rows, columns, block_hight, block_color, margin_top):
        self.__rows = rows
        self.__columns = columns
        self.__blockHight = block_hight
        self.__blockColor = block_color
        self.__margin_top = margin_top
        # 1つのブロックエリアの幅を計算
        self.__blockWidth = (pyxel.width - (columns + 1) * BLOCK_MARGIN) // columns
        # ブロックの左端位置の計算
        self.__blockMarginLeft = (pyxel.width - (self.__blockWidth * columns + (columns - 1) * BLOCK_MARGIN)) // 2
        # ブロック管理リスト
        self.__blocks = []

    def update(self, ball:Ball):
        # ボールとブロックの当たり判定
        for i in range(len(self.__blocks)-1, -1, -1):
            block:Block = self.__blocks[i]
            if ball.isCollision(block):
                del self.__blocks[i]
                pyxel.play(SOUND_CHANNEL, SOUND_BLOCK, loop=False)
        
    def draw(self):
        block:Block
        for block in self.__blocks:
            block.draw()

    # 初期化
    def reset(self):
        x = self.__blockMarginLeft
        y = self.__margin_top
        self.__blocks = []
        for _ in range(0, self.__rows):
            for _ in range(0, self.__columns):
                self.__blocks.append(Block(x, y, self.__blockWidth, self.__blockHight, self.__blockColor))
                x += (self.__blockWidth + BLOCK_MARGIN)
            y += (self.__blockHight + BLOCK_MARGIN)
            x = self.__blockMarginLeft