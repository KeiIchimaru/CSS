import pyxel
from paddle import Paddle

# V0.2 パドルを動かす

# ゲーム画面設定
FPS = 30
WINDOW_WIDTH = 160
WINDOW_HIGHT = 120

# パドル設定
PADDLE_WIDTH = 16
PADDLE_HIGHT = 2
PADDLE_COLOR = 10
PADDLE_SPEED = 2
PADDLE_Y = 115

class App:
    def __init__(self):
        pyxel.init(WINDOW_WIDTH, WINDOW_HIGHT, title="ブロック崩し", fps=FPS)
        self.paddle = Paddle(0, PADDLE_Y, PADDLE_WIDTH, PADDLE_HIGHT, PADDLE_COLOR, PADDLE_SPEED)
        self.paddle.center()
        pyxel.run(self.update, self.draw)    

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
        if pyxel.btn(pyxel.KEY_LEFT):
            self.paddle.left()
        if pyxel.btn(pyxel.KEY_RIGHT):
            self.paddle.right()

    def draw(self):
        pyxel.cls(0)
        self.paddle.draw()

App()