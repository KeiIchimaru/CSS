import pyxel
from block import Block

class Paddle(Block):
    def __init__(self, x, y, width, hight, color, speed):
        super().__init__(x, y, width, hight, color)
        self._speed = speed

    # 画面中央へ移動
    def center(self):
        self._x = (pyxel.width / 2) - (self._width / 2)

    # 右方向への移動
    def right(self):
        # パドルの左端(x)は（画面幅 - パドル幅）より小さいこと
        self._x = self._x + self._speed
        if self._x >= (pyxel.width - self._width):
            self._x = pyxel.width - self._width

    # 左方向への移動
    def left(self):
        # パドルの左端(x)は0以上であること
        self._x = self._x - self._speed
        if self._x < 0:
            self._x = 0