from rect import Rect
from circle import Circle

def __collisionRR(o1:Rect, o2:Rect):
    # 長方形の左上と右下
    o1_top_left = o1.topLeft
    o1_bottom_right = o1.bottomRight
    o2_top_left = o2.topLeft
    o2_bottom_right = o2.bottomRight
    # o1の左辺のX座標がo2の右辺のX座標よりも左側にある
    is_left_less_right = (o1_top_left.x <= o2_bottom_right.x)
    # o1の右辺のX座標がo2の左辺のX座標よりも右側にある
    is_right_greater_left  = (o1_bottom_right.x >= o2_top_left.x)
    # o1の上辺のY座標がo2の下辺のY座標よりも上側にある
    is_top_less_bottom = (o1_top_left.y <= o2_bottom_right.y)
    # o1の下辺のY座標がo2の上辺のY座標よりも下側にある
    is_bottom_greater_top = (o1_bottom_right.y >= o2_top_left.y)
    # 上記全てがTrueなら衝突している
    return is_left_less_right and is_right_greater_left and is_top_less_bottom and is_bottom_greater_top

def __collisionRC(o1:Rect, o2:Circle):
    # 長方形の左上と右下
    x1 = o1.x
    y1 = o1.y
    x2 = o1.bottomRight.x
    y2 = o1.bottomRight.y
    # 円の中心と半径
    xc = o2.x
    yc = o2.y
    r = o2.radius
    # 当たり判定1（左右方向の長方形部分）
    if (xc > x1) and (xc < x2) and (yc > (y1 - r)) and (yc < (y2 + r)):
        return True
    # 当たり判定2（上下方向の長方形部分）
    if (xc > (x1 - r)) and (xc < (x2 + r)) and (yc > y1) and (yc < y2):
        return True
    # 当たり判定3（左上の角丸部分）
    rr = r**2
    if ((x1 - xc)**2 + (y1 - yc)**2) < rr:
        return True
    # 当たり判定4（右上の角丸部分）
    if ((x2 - xc)**2 + (y1 - yc)**2) < rr:
        return True
    # 当たり判定5（左下の角丸部分）
    if ((x1 - xc)**2 + (y2 - yc)**2) < rr:
        return True
    # 当たり判定6（右下の角丸部分）
    if ((x2 - xc)**2 + (y2 - yc)**2) < rr:
        return True    
    return False

def __collisionCC(o1:Circle, o2:Circle):
    if ((o1.x - o2.x)**2 + (o1.y - o2.y)**2) < (o1.radius + o2.radius)**2:
        return True   

def isCollision(o1, o2):
    if isinstance(o1, Rect) and isinstance(o2, Rect):
        return __collisionRR(o1, o2)
    elif isinstance(o1, Circle) and isinstance(o2, Circle):
        return __collisionCC(o1, o2)
    elif isinstance(o1, Rect) and isinstance(o2, Circle):
        return __collisionRC(o1, o2)
    elif isinstance(o1, Circle) and isinstance(o2, Rect):
        return __collisionRC(o2, o1)
    return False
