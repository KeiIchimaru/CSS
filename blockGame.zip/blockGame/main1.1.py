import pyxel
from paddle import Paddle
from ball5 import Ball
from block_manager4 import BlockManager
from stageConfig import StageConfig

# V1.1 ゲームクリア追加

# ゲーム画面設定
FPS = 30
WINDOW_WIDTH = 160
WINDOW_HIGHT = 120
MARGIN_TOP = 7
SCORE_WEIGHT = 10
GAME_TIME = 3 #分

# ステージ情報
STAGE = []
STAGE.append(StageConfig())
STAGE.append(StageConfig(pw=10, lr=7))

# ゲームステータス
STATUS_BEFORE_START = 1
STATUS_START = 2
STATUS_ON_PLAY = 3
STATUS_GAME_CLEAR = 8
STATUS_GAME_OVER = 9

MESSAGE_GAME_OVER =\
"""
     GAME OVER
 
PUSH ENTER RESTART
"""
MESSAGE_GAME_CLEAR =\
"""
     GAME CLEAR
 << congratulation >>

  PUSH ENTER RESTART
"""

class App:
    def __init__(self):
        pyxel.init(WINDOW_WIDTH, WINDOW_HIGHT, title="ブロック崩し", fps=FPS)
        pyxel.load("resource.pyxres")
        self.count = 0
        self.time = 0
        self.score = 0
        self.status = STATUS_BEFORE_START
        self.level = 1
        self.paddle = Paddle(0, STAGE[self.level].PADDLE_Y,
                                STAGE[self.level].PADDLE_WIDTH,
                                STAGE[self.level].PADDLE_HIGHT,
                                STAGE[self.level].PADDLE_COLOR,
                                STAGE[self.level].PADDLE_SPEED)
        self.ball = Ball(0, 0, STAGE[self.level].BALL_RADIUS,
                               STAGE[self.level].BALL_COLOR,
                               -90, 
                               STAGE[self.level].BALL_SPEED,
                               MARGIN_TOP)
        self.blockManager = BlockManager(STAGE[self.level].BLOCK_ROWS,
                                         STAGE[self.level].BLOCK_COLUMNS,
                                         STAGE[self.level].BLOCK_HIGHT,
                                         STAGE[self.level].BLOCK_COLOR,
                                         MARGIN_TOP)
        pyxel.run(self.update, self.draw)    

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
        if self.status == STATUS_BEFORE_START:
            # ゲーム開始画面
            if pyxel.btn(pyxel.KEY_S):
                self.status = STATUS_START
                self.gameStart()
        elif self.status == STATUS_GAME_CLEAR or self.status == STATUS_GAME_OVER:
            # ゲームクリア & ゲームオーバー画面
            if pyxel.btn(pyxel.KEY_ENTER):
                self.status = STATUS_BEFORE_START
        else:
            # ゲーム中
            if pyxel.btn(pyxel.KEY_LEFT):
                self.paddle.left()
            if pyxel.btn(pyxel.KEY_RIGHT):
                self.paddle.right()
            if self.status == STATUS_START:
                # ボール発射前
                self.ball.moveOn(self.paddle.position)
                if pyxel.btn(pyxel.KEY_SPACE):
                    # ボール発射
                    self.status = STATUS_ON_PLAY
            else:
                # ボール発射後
                self.time -= 1
                if self.time <= 0:
                    self.status = STATUS_GAME_OVER
                else:
                    self.ball.update(self.paddle.position)
                    if (self.ball.y + self.ball.radius) >= pyxel.height:
                        self.status = STATUS_GAME_OVER
                    else:
                        self.score += (self.blockManager.update(self.ball) * SCORE_WEIGHT)
                        if not self.blockManager.hasBlocks():
                            self.status = STATUS_GAME_CLEAR
                            self.count = 0

    def draw(self):
        if self.status == STATUS_BEFORE_START:
            # ゲーム開始画面の描画
            pyxel.cls(0)
            pyxel.bltm(x=15, y=0, tm=0, u=0, v=0, w=16, h=16)
        elif self.status == STATUS_GAME_CLEAR:
            # ゲームクリア画面の描画
            self.count = (self.count + 1) % FPS
            color = 0 if self.count > FPS // 2 else 10
            pyxel.text(40, 40, MESSAGE_GAME_CLEAR, color)
        elif self.status == STATUS_GAME_OVER:
            # ゲームオーバー画面の描画
            pyxel.text(51, 40, MESSAGE_GAME_OVER, 1)
            pyxel.text(50, 40, MESSAGE_GAME_OVER, 7)
        else:
            # ゲーム中の画面描画
            pyxel.cls(0)
            self.blockManager.draw()
            self.ball.draw()
            self.paddle.draw()
            # スコア表示
            s = "SCORE {:>4}".format(self.score)
            pyxel.text(2, 1, s, 1)
            pyxel.text(1, 1, s, 7)
            # 残り時間表示
            s = "TIME {:>3}".format(self.time)
            pyxel.text(pyxel.width - 40, 1, s, 1)
            pyxel.text(pyxel.width - 40, 1, s, 7)

    def gameStart(self):
        self.score = 0
        self.time = GAME_TIME * 60 * FPS
        self.blockManager.reset()
        self.ball.reset()
        self.paddle.center()

App()