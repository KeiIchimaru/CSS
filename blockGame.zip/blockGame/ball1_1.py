import pyxel
import math
from circle import Circle
from rect import Rect

# V1.1 壁に反射する

class Ball(Circle):
    def __init__(self, x, y, radius, color, vector, speed):
        super().__init__(x, y, radius)
        self._color = color
        self._vector = self._initial_vector = vector
        self._speed = speed

    def update(self):
        self.move()

    def draw(self):
        pyxel.circ(self._x, self._y, self._radius, self._color)

    # 初期化
    def reset(self):
        self._vector = self._initial_vector

    # パドルに追随する
    def moveOn(self, paddle:Rect):
        self._x = paddle.x + paddle.width // 2
        self._y = paddle.y - self._radius - 1

    # 移動する
    def move(self):
        if self._vector > 0:
            direction = 1  # 上→下へ移動中
        else:
            direction = -1 # 下→上へ移動中
        self._x = self._x + self._speed * math.cos(math.radians(self._vector))
        self._y = self._y + self._speed * math.sin(math.radians(self._vector))
        if (self._x - self._radius) <= 0:
            # 左側の壁に衝突（ベクトルを垂直方向反転させる）-> 左向きの移動が右向きの移動に変化
            self._x = self._radius
            self._vector = (180 - abs(self._vector)) * direction
        elif (self._x + self._radius) >= pyxel.width:
            # 右側の壁に衝突（ベクトルを垂直方向反転させる）-> 右向きの移動が左向きの移動に変化
            self._x = pyxel.width - self._radius
            self._vector = (180 - abs(self._vector)) * direction
        elif (self._y - self._radius) <= 0:
            # 上側の壁に衝突（ベクトルを水平方向反転させる）-> 上方向への移動が下向きの移動に変化
            self._y = self._radius
            self._vector = -self._vector
        elif (self._y + self._radius) >= pyxel.height:
            # 下側の壁に衝突（ベクトルを水平方向反転させる）-> 下向きの移動が上向きの移動に変化
            self._y = pyxel.height - self._radius
            self._vector = -self._vector
