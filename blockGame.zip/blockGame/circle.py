class Circle:
    def __init__(self, x, y, radius):
        self._x = x
        self._y = y
        self._radius = radius

    @property
    def x(self):
        return self._x
    @property    
    def y(self):
        return self._y
    @property
    def radius(self):
        return self._radius

    @property
    def position(self):
        return Circle(self._x, self._y, self._radius)
