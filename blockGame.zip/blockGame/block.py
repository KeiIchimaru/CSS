import pyxel
from rect import Rect

class Block(Rect):
    def __init__(self, x, y, width, hight, color):
        super().__init__(x, y, width, hight)
        self._color = color

    def draw(self):
        pyxel.rect(self._x, self._y, self._width, self._hight, self._color)
