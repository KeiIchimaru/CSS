class StageConfig:
    def __init__(self, pw=16, ph=2, pc=10, ps=3, py=115, br=3, bc=6, bs=3, lr=5, lcs=10, lh=5, lc=8):
        # パドル設定
        self.PADDLE_WIDTH = pw
        self.PADDLE_HIGHT = ph
        self.PADDLE_COLOR = pc
        self.PADDLE_SPEED = ps
        self.PADDLE_Y = py

        # ボール設定
        self.BALL_RADIUS = br
        self.BALL_COLOR = bc
        self.BALL_SPEED = bs

        # ブロック設定
        self.BLOCK_ROWS = lr
        self.BLOCK_COLUMNS = lcs
        self.BLOCK_HIGHT = lh
        self.BLOCK_COLOR = lc

if __name__ == '__main__':
    s = StageConfig(10, lr=8)
    print(s.PADDLE_WIDTH)
    print(s.PADDLE_HIGHT)
    print(s.BLOCK_ROWS)
