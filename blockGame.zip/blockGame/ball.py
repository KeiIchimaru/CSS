import pyxel
import math
from circle import Circle
from rect import Rect

# V0 パドルに追随する

class Ball(Circle):
    def __init__(self, x, y, radius, color, vector, speed):
        super().__init__(x, y, radius)
        self._color = color
        self._vector = self._initial_vector = vector
        self._speed = speed

    def update(self):
        pass

    def draw(self):
        pyxel.circ(self._x, self._y, self._radius, self._color)

    # 初期化
    def reset(self):
        self._vector = self._initial_vector

    # パドルに追随する
    def moveOn(self, paddle:Rect):
        self._x = paddle.x + paddle.width // 2
        self._y = paddle.y - self._radius - 1