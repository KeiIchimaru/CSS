import pyxel
import math
from circle import Circle
from rect import Rect
from collision import isCollision

# V3 パドルとの衝突チェック追加

SOUND_CHANNEL = 1
SOUND_PADDLE = 0
SOUND_WALL = 1

class Ball(Circle):
    def __init__(self, x, y, radius, color, vector, speed):
        super().__init__(x, y, radius)
        self._color = color
        self._vector = self._initial_vector = vector
        self._speed = speed

    def update(self, rect:Rect):
        self.move()
        if self.isCollision(rect):
            pyxel.play(SOUND_CHANNEL, SOUND_PADDLE, loop=False)

    def isCollision(self, rect:Rect):
        # 長方形との衝突チェック
        if not isCollision(self.position, rect):
            return False
        # 衝突した場合（長方形＝パドルの上面のみに衝突する前提）
        self._y = rect.y - self._radius - 1
        if abs(self._vector) == 90:
            # 垂直方向で長方形に当たった場合、衝突位置により反射角度を変える
            xc = rect.x + rect.width // 2
            if self._x >= (xc - 1) and self._x <= (xc + 1):
                self._vector = -self._vector
            else:
                dis = abs(self._x - xc) / 10
                self._vector = max(int(math.degrees(math.acos(dis))), 5)
                if self._x < xc:
                    self._vector = 180 - self._vector
                self._vector = -self._vector
        else:
            self._vector = -self._vector
        return True

    def draw(self):
        pyxel.circ(self._x, self._y, self._radius, self._color)

    # 初期化
    def reset(self):
        self._vector = self._initial_vector

    # パドルに追随する
    def moveOn(self, paddle:Rect):
        self._x = paddle.x + paddle.width // 2
        self._y = paddle.y - self._radius

    # 移動する
    def move(self):
        if self._vector > 0:
            direction = 1  # 上→下へ移動中
        else:
            direction = -1 # 下→上へ移動中
        self._x = self._x + self._speed * math.cos(math.radians(self._vector))
        self._y = self._y + self._speed * math.sin(math.radians(self._vector))
        if (self._x - self._radius) <= 0:
            # 左側の壁に衝突（ベクトルを垂直方向反転させる）-> 左向きの移動が右向きの移動に変化
            self._x = self._radius
            self._vector = (180 - abs(self._vector)) * direction
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)
        elif (self._x + self._radius) >= pyxel.width:
            # 右側の壁に衝突（ベクトルを垂直方向反転させる）-> 右向きの移動が左向きの移動に変化
            self._x = pyxel.width - self._radius
            self._vector = (180 - abs(self._vector)) * direction
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)
        elif (self._y - self._radius) <= 0:
            # 上側の壁に衝突（ベクトルを水平方向反転させる）-> 上方向への移動が下向きの移動に変化
            self._y = self._radius
            self._vector = -self._vector
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)
        elif (self._y + self._radius) >= pyxel.height:
            # 下側の壁に衝突（ベクトルを水平方向反転させる）-> 下向きの移動が上向きの移動に変化
            self._y = pyxel.height - self._radius
            self._vector = -self._vector
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)