from point import Point

class Rect:
    def __init__(self, x, y, width, hight):
        self._x = x
        self._y = y
        self._width = width
        self._hight = hight

    @property
    def x(self):
        return self._x
    @property
    def y(self):
        return self._y
    @property
    def width(self):
        return self._width
    @property
    def hight(self):
        return self._hight

    @property
    def position(self):
        return Rect(self._x, self._y, self._width, self._hight)
    @property
    def topLeft(self) -> Point:
        return Point(self._x, self._y)
    @property
    def topRight(self) -> Point:
        return Point(self._x + self._width, self._y)
    @property
    def bottomLeft(self) -> Point:
        return Point(self._x, self._y + self._hight)
    @property
    def bottomRight(self) -> Point:
        return Point(self._x + self._width, self._y + self._hight)

if __name__ == '__main__':
    r = Rect(10,20,30,40)
    print(r)
    print(r.position)