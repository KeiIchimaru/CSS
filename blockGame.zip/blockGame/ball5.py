import pyxel
import math
from circle import Circle
from rect import Rect
from point import Point
from collision import isCollision

# V5 ブロックとの衝突チェック追加

SOUND_CHANNEL = 1
SOUND_PADDLE = 0
SOUND_WALL = 1

class Ball(Circle):
    def __init__(self, x, y, radius, color, vector, speed, margin_top):
        super().__init__(x, y, radius)
        self._color = color
        self._vector = self._initial_vector = vector
        self._speed = speed
        self._margin_top = margin_top

    def update(self, rect:Rect):
        self.move()
        if self.isCollision(rect):
            pyxel.play(SOUND_CHANNEL, SOUND_PADDLE, loop=False)

    def isCollision(self, rect:Rect):
        # 長方形との衝突チェック
        if not isCollision(self.position, rect):
            return False
        # 衝突した場合
        bottomRight:Point = rect.bottomRight
        if self._y <= rect.y and self._x >= rect.x and self._x <= bottomRight.x:
            # 長方形の上面と衝突
            self. __collisionTopBottom(rect)
        elif self._y >= bottomRight.y and self._x >= rect.x and self._x <= bottomRight.x:
            # 長方形の下面と衝突
            self. __collisionTopBottom(rect)
        elif self._x <= rect.x:
            # 長方形の左側面と衝突
            self.__collisionLeftRight(rect)
        else:
            # 長方形の右側面と衝突
            self.__collisionLeftRight(rect)
        return True

    def __collisionTopBottom(self, rect:Rect):
        if self._vector > 0:
            # 上から下に移動中に上面に衝突
            self._y = rect.y - self._radius
            direction = -1 # 下→上へ
        else:
            # 下から上に移動中に下面に衝突
            self._y = rect.bottomRight.y + self._radius
            direction = 1 # 上→下へ
        if abs(self._vector) == 90:
            xc = rect.x + rect.width // 2
            if self._x >= (xc - 1) and self._x <= (xc + 1):
                # 長方形の横方向中心に衝突
                self._vector = abs(self._vector) * direction
            else:
                # 衝突位置により反射角度を変える
                dis = abs(self._x - xc) / 10
                self._vector = max(int(math.degrees(math.acos(dis))), 5)
                if self._x < xc:
                    self._vector = 180 - self._vector
                self._vector = self._vector * direction
        else:
            self._vector = -self._vector

    def __collisionLeftRight(self, rect:Rect):
        if self._x <= rect.x:
            # 左側側面に衝突
            self._x = rect.x - self._radius
        else:
            # 右側側面に衝突
            self._x = rect.bottomRight.x + self._radius
        if self._vector > 0:
            self._vector = 180 - self._vector
        else:
            self._vector = -(180 + self._vector) 

    def draw(self):
        pyxel.circ(self._x, self._y, self._radius, self._color)

    # 初期化
    def reset(self):
        self._vector = self._initial_vector

    # パドルに追随する
    def moveOn(self, paddle:Rect):
        self._x = paddle.x + paddle.width // 2
        self._y = paddle.y - self._radius

    # 移動する
    def move(self):
        if self._vector > 0:
            direction = 1  # 上→下へ移動中
        else:
            direction = -1 # 下→上へ移動中
        self._x = self._x + self._speed * math.cos(math.radians(self._vector))
        self._y = self._y + self._speed * math.sin(math.radians(self._vector))
        if (self._x - self._radius) <= 0:
            # 左側の壁に衝突（ベクトルを垂直方向反転させる）
            self._x = self._radius
            self._vector = (180 - abs(self._vector)) * direction
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)
        elif (self._x + self._radius) >= pyxel.width:
            # 右側の壁に衝突（ベクトルを垂直方向反転させる）
            self._x = pyxel.width - self._radius
            self._vector = (180 - abs(self._vector)) * direction
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)
        elif (self._y - self._radius) <= self._margin_top:
            # 上側の壁に衝突（ベクトルを水平方向反転させる）
            self._y = self._margin_top + self._radius
            self._vector = -self._vector
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)
        elif (self._y + self._radius) >= pyxel.height:
            # 下側の壁に衝突（ベクトルを水平方向反転させる）
            self._y = pyxel.height - self._radius
            self._vector = -self._vector
            pyxel.play(SOUND_CHANNEL, SOUND_WALL, loop=False)