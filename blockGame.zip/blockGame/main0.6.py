import pyxel
from paddle import Paddle
from ball3 import Ball

# V0.6 パドルとボールの衝突チェック

# ゲーム画面設定
FPS = 30
WINDOW_WIDTH = 160
WINDOW_HIGHT = 120

# パドル設定
PADDLE_WIDTH = 16
PADDLE_HIGHT = 2
PADDLE_COLOR = 10
PADDLE_SPEED = 2
PADDLE_Y = 115

# ボール設定
BALL_RADIUS = 3
BALL_COLOR = 6
BALL_SPEED = 3

class App:
    def __init__(self):
        pyxel.init(WINDOW_WIDTH, WINDOW_HIGHT, caption="ブロック崩し", fps=FPS)
        pyxel.load("resource.pyxres")
        self.start = False
        self.paddle = Paddle(0, PADDLE_Y, PADDLE_WIDTH, PADDLE_HIGHT, PADDLE_COLOR, PADDLE_SPEED)
        self.ball = Ball(0, 0, BALL_RADIUS, BALL_COLOR, -90, BALL_SPEED)
        pyxel.run(self.update, self.draw)    

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
        if not self.start:
            # <----- ゲーム開始前 ----->
            if pyxel.btn(pyxel.KEY_S):
                self.start = True
                self.onPlay = False
                self.paddle.center()
                self.ball.reset()
        else:
            # <----- ゲーム中 --------->
            # パドルの移動
            if pyxel.btn(pyxel.KEY_LEFT):
                self.paddle.left()
            if pyxel.btn(pyxel.KEY_RIGHT):
                self.paddle.right()
            if not self.onPlay:
                # ボール発射前
                self.ball.moveOn(self.paddle.position)
                if pyxel.btn(pyxel.KEY_SPACE):
                    # ボール発射
                    self.onPlay = True
            else:
                # ボール発射後
                self.ball.update(self.paddle.position)

    def draw(self):
        if not self.start:
            # ゲーム開始画面の描画
            pyxel.cls(0)
            pyxel.bltm(x=15, y=0, tm=0, u=0, v=0, w=16*8, h=16*8)
        else:
            # ゲーム中の画面描画
            pyxel.cls(0)
            self.paddle.draw()
            self.ball.draw()

App()