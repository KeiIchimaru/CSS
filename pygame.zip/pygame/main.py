import pygame
import time

class Paddle:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.dx = 0  # パドルの移動速度

    def move(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.dx = -5
        elif keys[pygame.K_RIGHT]:
            self.dx = 5
        else:
            self.dx = 0
        
        self.x += self.dx

        # 画面の端で停止する
        if self.x < 0:
            self.x = 0
        elif self.x + self.width > 800:
            self.x = 800 - self.width

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))

class Ball:
    def __init__(self, x, y, radius, color):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.dx = 5  # ボールのx方向の速度
        self.dy = 5  # ボールのy方向の速度
        self.in_motion = False  # ボールが動いているかどうか

    def move(self, paddle, app):
        if not self.in_motion:
            self.x = paddle.x + paddle.width // 2
            self.y = paddle.y - self.radius
            keys = pygame.key.get_pressed()
            if keys[pygame.K_SPACE]:
                self.in_motion = True
                self.dy = -5

        if self.in_motion:
            self.x += self.dx
            self.y += self.dy

            # 画面の端で反射する
            if self.x - self.radius < 0 or self.x + self.radius > 800:
                self.dx *= -1
            if self.y - self.radius < 0:
                self.dy *= -1

            # ボールがパドルに当たったかどうかの判定
            if (self.y + self.radius >= paddle.y and
                paddle.x <= self.x <= paddle.x + paddle.width):
                self.dy *= -1

            # ボールがウィンドウの下部に当たったらゲーム終了
            if self.y + self.radius > 600:
                app.running = False

            # ボールがブロックに当たったかどうかの判定
            for block in app.blocks[:]:
                if (block.x < self.x < block.x + block.width and
                    block.y < self.y < block.y + block.height):
                    app.blocks.remove(block)
                    self.dy *= -1
                    break

    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)

class Block:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))

class App:
    def __init__(self):
        # pygameを初期化します
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption('ブロック崩しゲーム')
        self.clock = pygame.time.Clock()
        self.running = True
        self.ball = Ball(400, 300, 20, (255, 0, 0))  # ボールを初期化します
        self.paddle = Paddle(350, 580, 100, 10, (0, 255, 0))  # パドルを初期化します
        self.blocks = self.create_blocks()  # ブロックを初期化します
        self.start_time = time.time()  # ゲーム開始時刻を記録

    def create_blocks(self):
        blocks = []
        block_width = 150
        block_height = 30
        gap = 3
        start_x = 10
        start_y = 10
        for row in range(3):
            for col in range(5):
                x = start_x + col * (block_width + gap)
                y = start_y + row * (block_height + gap)
                blocks.append(Block(x, y, block_width, block_height, (255, 255, 255)))
        return blocks

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
            
            # 経過時間を計算
            elapsed_time = int(time.time() - self.start_time)
            
            # 画面を黒で塗りつぶす
            self.screen.fill((0, 0, 0))
            
            # ボールとパドルを動かして描画する
            self.ball.move(self.paddle, self)
            self.ball.draw(self.screen)
            self.paddle.move()
            self.paddle.draw(self.screen)

            # ブロックを描画する
            for block in self.blocks:
                block.draw(self.screen)

            # スコア（経過時間）を表示する
            font = pygame.font.Font(None, 36)
            score_text = font.render(f'Score: {elapsed_time}', True, (255, 255, 255))
            self.screen.blit(score_text, (10, 10))

            # 全てのブロックが消えた場合、ゲームクリア
            if not self.blocks:
                self.running = False
                print("ゲームクリア！")

            # 画面を更新する
            pygame.display.flip()
            self.clock.tick(60)

        pygame.quit()

if __name__ == '__main__':
    app = App()
    app.run()
