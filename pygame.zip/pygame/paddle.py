import pygame

class Paddle:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.dx = 0  # パドルの移動速度

    def move(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.dx = -5
        elif keys[pygame.K_RIGHT]:
            self.dx = 5
        else:
            self.dx = 0
        
        self.x += self.dx

        # 画面の端で停止する
        if self.x < 0:
            self.x = 0
        elif self.x + self.width > 800:
            self.x = 800 - self.width

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))
