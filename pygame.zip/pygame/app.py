import pygame
import time
from ball import Ball
from paddle import Paddle
from block import Block

class App:
    def __init__(self):
        # pygameを初期化します
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption('ブロック崩しゲーム')
        self.clock = pygame.time.Clock()
        self.running = True
        self.in_motion = False # ボールが動いているかどうか
        self.ball = Ball(20, (255, 0, 0)) # ボールを初期化します
        self.paddle = Paddle(350, 580, 100, 10, (0, 255, 0))  # パドルを初期化します
        self.blocks = self.create_blocks()  # ブロックを初期化します

    def create_blocks(self):
        blocks = []
        block_width = 150
        block_height = 30
        gap = 3
        start_x = 10
        start_y = 10
        for row in range(3):
            for col in range(5):
                x = start_x + col * (block_width + gap)
                y = start_y + row * (block_height + gap)
                blocks.append(Block(x, y, block_width, block_height, (255, 255, 255)))
        return blocks

    def run(self):
        while self.running:
            self.update()
            if self.running:
                self.drow()
                self.clock.tick(60)
        pygame.quit()

    def update(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return
        keys = pygame.key.get_pressed()
        if keys[pygame.K_q]:
            self.running = False
            return
        elif keys[pygame.K_SPACE]:
            self.in_motion = True
            self.ball.set_in_motion()
            self.start_time = time.time() # ゲーム開始時刻を記録

        # ボールとパドルを動かす
        if self.in_motion:
            self.running = self.ball.move(self.paddle)
        else:
            self.ball.moveOn(self.paddle)
        self.paddle.move()

    def drow(self):
        # 画面を黒で塗りつぶす
        self.screen.fill((0, 0, 0))
        
        # ボールとパドルを描画
        self.ball.draw(self.screen)
        self.paddle.draw(self.screen)

        # ブロックを描画する
        for block in self.blocks:
            block.draw(self.screen)

        if self.in_motion:
            # 経過時間を計算
            elapsed_time = int(time.time() - self.start_time)
            # スコア（経過時間）を表示する
            font = pygame.font.Font(None, 36)
            score_text = font.render(f'Score: {elapsed_time}', True, (255, 255, 255))
            self.screen.blit(score_text, (10, 10))

        # 画面を更新する
        pygame.display.flip()

if __name__ == '__main__':
    app = App()
    app.run()
