import pygame
from paddle import Paddle

class Ball:
    def __init__(self, radius, color):
        self.x = 0
        self.y = 0
        self.radius = radius
        self.color = color
        self.dx = 5  # ボールのx方向の速度
        self.dy = 5  # ボールのy方向の速度

    def set_in_motion(self):
        self.in_motion = True
        self.dy = -5

    # パドルに追随する
    def moveOn(self, paddle: Paddle):
        self.x = paddle.x + paddle.width // 2
        self.y = paddle.y - self.radius

    # 移動する
    def move(self, paddle: Paddle) -> bool:
        self.x += self.dx
        self.y += self.dy

        # 画面の端で反射する
        if self.x - self.radius < 0 or self.x + self.radius > 800:
            self.dx *= -1
        if self.y - self.radius < 0:
            self.dy *= -1

        # ボールがパドルに当たったかどうかの判定
        if (self.y + self.radius >= paddle.y and
            paddle.x <= self.x <= paddle.x + paddle.width):
            self.dy *= -1

        # ボールがウィンドウの下部に当たったらゲーム終了
        return not (self.y + self.radius > 600)

    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
