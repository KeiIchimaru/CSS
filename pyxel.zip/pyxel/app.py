import pyxel
from  random import randint

# ゲーム全体の定数
FPS = 30
WIDTH = 32
HEIGHT = 16
BG_COLOR = 6
FAR_CLOUD_SPEED = 8
NEAR_CLOUD_SPEED = 2
# プレーヤー画像の情報
PLAYER_WIDTH = 16
PLAYER_HEIGHT = 16
PLAYER_IMAGE_X = 0
PLAYER_IMAGE_Y = 48
# 敵画像の情報
ENEMY_WIDTH = 16
ENEMY_HEIGHT = 16
ENEMY_IMAGE_X = 0
ENEMY_IMAGE_Y = 64
MAXIMUM_ENEMY_TYPES = 3

# ゲームの難易度を変える定数
INIT_GRAVITY = 2.5
INIT_POWER = 0.25
ENEMY_SPACING = 60
ENEMY_SPEED = 2

class App:
    def __init__(self):
        self.width = WIDTH * 8
        self.height = HEIGHT * 8
        pyxel.init(self.width, self.height, title="Jump Jump Pyxel", fps=FPS)
        pyxel.load("assets.pyxres")
        self.reset()
        pyxel.run(self.update, self.draw)

    def reset(self):
        # プレーヤーの初期位置
        self.player_x = 20
        self.player_y = self.height // 2 - PLAYER_HEIGHT // 2
        #重力系変数
        self.gravity = INIT_GRAVITY
        self.power = INIT_POWER
        self.max_gravity = self.gravity
        # 敵キャラ
        self.enemys = []
        for i in range(3, 15):
            self.enemys.append((i*ENEMY_SPACING, randint(0, self.height-ENEMY_HEIGHT), randint(0,MAXIMUM_ENEMY_TYPES-1)))
        #遠い雲
        self.far_cloud =  [(10, 25), (34, 95), (57, 65), (80, 45), (110, 95), (120, 15)]
        self.far_cloud += [(100, 55), (160, 65), (190, 75), (210, 37), (240, 10)]
        #近い雲
        self.near_cloud = [(20, 15), (40, 75), (110, 40), (180, 72)]

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
        self.update_player()
        for i, v in enumerate(self.enemys):
            self.enemys[i] = self.update_enemy(*v)

    def update_player(self): 
        if pyxel.btn(pyxel.KEY_SPACE):
            # スペースを押している間は上へ移動
            if self.gravity > -self.max_gravity:
                self.gravity = self.gravity - self.power
        else:
            # スペースが押されていない場合は下へ移動
            if self.gravity < self.max_gravity:
                self.gravity = self.gravity + self.power
        # プレイヤー移動（上下のみ）
        self.player_y = self.player_y + self.gravity 
        if 0 > self.player_y:
            self.player_y = 0 
        if self.player_y > (pyxel.height - PLAYER_HEIGHT):
            self.player_y = pyxel.height - PLAYER_HEIGHT 

    def update_enemy(self, x, y, p):
        x -= ENEMY_SPEED
        if x < -40:
            x += (12*ENEMY_SPACING)
            y = randint(0, self.height-ENEMY_HEIGHT)
            p = randint(0,MAXIMUM_ENEMY_TYPES-1)
        return (x, y, p)

    def draw(self):
        # 背景表示  x  y tm  u  v  w           h
        pyxel.bltm(0, 0, 0, 0, 0, self.width, self.height)
        # 遠い雲の表示
        offset = (pyxel.frame_count // FAR_CLOUD_SPEED) % self.width
        for i in range(2):
            # 2回描画する（1=0:左に消えていく雲、i=1:右から入ってくる雲）
            for x, y in self.far_cloud:
                px = x + i * self.width - offset
                #         x   y img u  v   w   h
                pyxel.blt(px, y, 0, 0, 40, 32, 8, BG_COLOR)
        # プレーヤー表示
        pyxel.blt(self.player_x, self.player_y, 0, PLAYER_IMAGE_X, PLAYER_IMAGE_Y, PLAYER_WIDTH, PLAYER_HEIGHT, BG_COLOR)
        # 敵キャラ表示
        for x, y, p in self.enemys:
            pyxel.blt(x, y, 0, ENEMY_IMAGE_X+p*ENEMY_WIDTH, ENEMY_IMAGE_Y, ENEMY_WIDTH, ENEMY_HEIGHT, BG_COLOR)
        # 近い雲の表示
        offset = (pyxel.frame_count // NEAR_CLOUD_SPEED) % self.width
        for i in range(2):
            for x, y in self.near_cloud:
                px = x + i * self.width - offset
                #         x   y img u   v   w   h
                pyxel.blt(px, y, 0, 32, 38, 24, 8, BG_COLOR)

App()
