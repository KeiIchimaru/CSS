import pyxel
from  random import randint

# ゲーム全体の定数
FPS = 30
WIDTH = 32
HEIGHT = 16

class App:
    def __init__(self):
        self.width = WIDTH * 8
        self.height = HEIGHT * 8
        pyxel.init(self.width, self.height, title="Jump Jump Pyxel", fps=FPS)
        pyxel.load("assets01.pyxres")
        self.reset()
        pyxel.run(self.update, self.draw)

    def reset(self):
        pass

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()

    def draw(self):
        # 背景表示  x  y tm  u  v   w    h
        pyxel.bltm(0, 0, 0, 0, 0, self.width, self.height)
        pass

App()
