import pyxel
from  random import randint

# ゲーム全体の定数
FPS = 30
WIDTH = 32
HEIGHT = 16
BG_COLOR = 6
FAR_CLOUD_SPEED = 8
NEAR_CLOUD_SPEED = 2
PLAYER_IMAGE_X = 0
PLAYER_IMAGE_Y = 48
PLAYER_WIDTH = 16
PLAYER_HEIGHT = 16

class App:
    def __init__(self):
        self.width = WIDTH * 8
        self.height = HEIGHT * 8
        pyxel.init(self.width, self.height, title="Jump Jump Pyxel", fps=FPS)
        pyxel.load("assets04.pyxres")
        self.reset()
        pyxel.run(self.update, self.draw)

    def reset(self):
        # プレーヤーの初期位置
        self.player_x = 20
        self.player_y = self.height // 2 - PLAYER_HEIGHT // 2
        #遠い雲
        self.far_cloud =  [(10, 25), (34, 95), (57, 65), (80, 45), (110, 95), (120, 15)]
        self.far_cloud += [(100, 55), (160, 65), (190, 75), (210, 37), (240, 10)]
        #近い雲
        self.near_cloud = [(20, 15), (40, 75), (110, 40), (180, 72)]

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()

    def draw(self):
        # 背景表示  x  y tm  u  v  w           h
        pyxel.bltm(0, 0, 0, 0, 0, self.width, self.height)
        # 遠い雲の表示
        offset = (pyxel.frame_count // FAR_CLOUD_SPEED) % self.width
        for i in range(2):
            # 2回描画する（1=0:左に消えていく雲、i=1:右から入ってくる雲）
            for x, y in self.far_cloud:
                px = x + i * self.width - offset
                #         x   y img u  v   w   h
                pyxel.blt(px, y, 0, 0, 40, 32, 8, BG_COLOR)
        # プレーヤー表示
        pyxel.blt(self.player_x, self.player_y, 0, PLAYER_IMAGE_X, PLAYER_IMAGE_Y, PLAYER_WIDTH, PLAYER_HEIGHT, BG_COLOR)
        # 近い雲の表示
        offset = (pyxel.frame_count // NEAR_CLOUD_SPEED) % self.width
        for i in range(2):
            for x, y in self.near_cloud:
                px = x + i * self.width - offset
                #         x   y img u   v   w   h
                pyxel.blt(px, y, 0, 32, 38, 24, 8, BG_COLOR)


App()
