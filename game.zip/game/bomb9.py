import os
import question

bomb = list("---------------〇")
boom = ["",
        " BBBB   OOO   OOO  M    M  !!",
        " B   B O   O O   O MM  MM  !!",
        " B   B O   O O   O M MM M  !!",
        " BBBB  O   O O   O M    M  !!",
        " B   B O   O O   O M    M  !!",
        " B   B O   O O   O M    M    ",
        " BBBB   OOO   OOO  M    M  !!",
        ""]
word = question.getQuestion()
chars = list(word[0])
checks = ["_"] * len(word[0])
wrong = 0
win = False
while wrong  < len(bomb) - 1:
    os.system('cls')
    if wrong < len(bomb)-1:
        bomb[wrong] = "*"
    else:
        bomb[wrong] = "＊"
    print("".join(bomb))
    char = input("\n１文字を予想してね！({})[{}]:".format("".join(checks), len(checks)))
    if char in chars:
        i = chars.index(char)
        checks[i] = char
        chars[i] = "$"
    else:
        bomb[wrong] = " "
        wrong += 1
    if "_" not in checks:
        os.system('cls')
        print("".join(bomb))
        print("\nあなたの勝ち！正解は{}({}).".format(word[0], word[1]))
        win = True
        break
if not win:
    os.system('cls')
    print("\nあなたの負け！正解は{}({}).".format(word[0], word[1]))
    for x in range(len(boom)):
        print(boom[x])
