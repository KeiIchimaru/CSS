import pyxel
from  random import randint

FPS = 30
MESSAGE_START ="PUSH SPACE KEY"
MESSAGE_GAMEOVER =\
"""
     GAMEOVER
 
PUSH ENTER RESTART
"""
class App:
    def __init__(self):
        pyxel.init(160, 120, title="Jump Jump Pyxel", fps=FPS)
        pyxel.load("bomb.pyxres")
        self.reset()
        pyxel.run(self.update, self.draw)
 
    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
        if not self.START and pyxel.btn(pyxel.KEY_SPACE):
            self.START = True
        if self.GAMEOVER and (pyxel.btn(pyxel.KEY_RETURN)) :
            self.reset()
        if not self.START or self.GAMEOVER:
            return
        self.update_player()
        for i, v in enumerate(self.bomb):
            self.bomb[i] = self.update_bomb(*v)
        if not self.GAMEOVER:
            self.score += 1
  
    def draw(self):
        # ゲームオーバー表示
        if self.GAMEOVER:
            pyxel.text(51, 40, MESSAGE_GAMEOVER, 1)
            pyxel.text(50, 40, MESSAGE_GAMEOVER, 7)
            return
        # 背景表示  x  y tm  u  v   w   h  colkey
        pyxel.bltm(0, 0, 0, 0, 0, 160, 120)
        # 遠い雲の表示
        offset = (pyxel.frame_count // 8) % 160
        for i in range(2):
            for x, y in self.far_cloud:
                pyxel.blt(x + i * 160 - offset, y, 0, 0, 56, 22, 8, 12)
        # キャラクタ表示
        if not self.GAMEOVER:
            pyxel.blt(self.player_x, self.player_y, 0, 0, 0, 16, 16, 0)
        # 爆弾表示
        for x, y in self.bomb:
            pyxel.blt(x, y, 0, 32, 0, 16, 16, 7)
        # 近い雲の表示
        offset = (pyxel.frame_count // 2) % 160
        for i in range(2):
            for x, y in self.near_cloud:
                pyxel.blt(x + i * 160 - offset, y, 0, 32, 56, 22, 8, 12)
        # スコア表示
        s = "SCORE {:>4}".format(self.score)
        pyxel.text(5, 4, s, 1)
        pyxel.text(4, 4, s, 7)
        # 開始の表示
        if not self.START:
            pyxel.text(61, 50, MESSAGE_START, 1)
            pyxel.text(60, 50, MESSAGE_START, 7)
 
    def update_player(self): 
        if pyxel.btn(pyxel.KEY_SPACE):
            # 上へ移動
            if self.gravity > -self.MAX_GRAVITY:
                self.gravity = self.gravity - self.POWER
        else:
            # 下へ移動
            if self.gravity < self.MAX_GRAVITY:
                self.gravity = self.gravity + self.POWER
        # プレイヤー移動（上下のみ）
        self.player_y = self.player_y + self.gravity 
        if 0 > self.player_y:
            self.player_y = 0 
        if self.player_y > pyxel.height -16:
            self.player_y = pyxel.height - 16 
 
    def update_bomb(self, x, y):
        # 衝突チェック
        if abs(x - self.player_x) < 12 and abs(y - self.player_y) < 12:
            self.GAMEOVER = True
            pyxel.blt(x, y, 0, 48, 0, 16, 16, 0)
            pyxel.blt(self.player_x, self.player_y, 0, 16, 0, 16, 16, 0)
            pyxel.stop()
        x -= 2
        if x < -40:
            x += 240
            y = randint(0, 104)
        return (x, y)
 
    def reset(self):
        self.START = False
        self.GAMEOVER = False
        self.score = 0
        self.player_x = 20
        self.player_y = 60        
        #重力系変数
        self.gravity = 2.5
        self.MAX_GRAVITY = self.gravity
        self.POWER = 0.25
        self.bomb = [(i * 60, randint(0, 104)) for i in range(3,15)]
        #遠い雲
        self.far_cloud = [(10, 25), (70, 35), (120, 15), (44, 45), (67, 75), (110, 95)]
        #近い雲
        self.near_cloud = [(20, 15), (40, 75), (110, 40)]
        #音再生
        pyxel.playm(0, loop=True)
 
App()