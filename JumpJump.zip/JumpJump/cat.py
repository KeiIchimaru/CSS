import pyxel
from random import randint
from collections import namedtuple
import math

Target = namedtuple("Target", ["x", "y", "y2", "resX", "resY"])
BASE_X = 40
BASE_Y = 20
FPS = 30

class App:
    def __init__(self):
        pyxel.init(160, 120, title="Hello Pyxel", fps=FPS)
        #pyxel.image(0).load(0, 0, "C:\\Users\\keiic\\pyxel_examples\\assets\\cat_16x16.png")
        pyxel.load("cat.pyxres")
        self.score = 0
        self.count = 0
        self.count_max = FPS * 1 * 60
        self.player_x = 0
        self.player_y = 60
        self.targets = []
        self.targets.append(Target(pyxel.width+BASE_X*0, randint(BASE_Y, pyxel.height-BASE_Y), 0, 16, 0))
        self.targets.append(Target(pyxel.width+BASE_X*1, randint(BASE_Y, pyxel.height-BASE_Y), 0, 32, 0))
        self.targets.append(Target(pyxel.width+BASE_X*2, randint(BASE_Y, pyxel.height-BASE_Y), 0, 16, 0))
        self.targets.append(Target(pyxel.width+BASE_X*1, randint(BASE_Y, pyxel.height-BASE_Y), 0,  0,16))
        pyxel.run(self.update, self.draw)

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
        if self.count < self.count_max:
            self.count = self.count + 1
            self.update_player()
            for i, ele in enumerate(self.targets):
                self.targets[i] = self.update_target(ele)

    def update_player(self):
        if pyxel.btn(pyxel.KEY_LEFT):
            self.player_x = max(self.player_x - 2, 0)
        if pyxel.btn(pyxel.KEY_RIGHT):
            self.player_x = min(self.player_x + 2, pyxel.width - 16)
        if pyxel.btn(pyxel.KEY_UP):
            self.player_y = max(self.player_y - 2, 0)
        if pyxel.btn(pyxel.KEY_DOWN):
            self.player_y = min(self.player_y + 2, pyxel.height - 16)

    def update_target(self, target):
        # 猫とターゲットの距離を計算
        px = self.player_x + 8
        py = self.player_y + 8
        tx = target.x + 8
        ty = target.y + 8
        bx = abs(px - tx)
        by = abs(py - ty)
        # 右へ移動
        x = target.x - 4
        # 上下に変則移動（sinカーブ）
        y2 = target.y2 if target.y2 != 0 else target.y
        s = math.sin(math.radians(self.count*10))
        h = int(16 * s * 2)
        y = target.y2 + h
        # 衝突チェック
        if bx < 12 and by < 12:
            self.score = self.score + 100
            pyxel.sound(0).speed = 5
            pyxel.play(1,0,loop=False)
            x = -40
        # ターゲットの画像変更（無）
        resX = target.resX
        resY = target.resY
        # 右側枠外へ移動
        if x < -40:
            x = pyxel.width + BASE_X * randint(0, 10)
            print(x)
            y = randint(BASE_Y, pyxel.height-BASE_Y)
        return Target(x, y, y2, resX, resY)

    def draw(self):
        pyxel.cls(0)
        pyxel.blt(self.player_x, self.player_y, 0,   0, 0, 16, 16, 13)
        for ele in self.targets:
            pyxel.blt(ele.x, ele.y, 0, ele.resX, ele.resY, 16, 16, 13)
        s = "Score {:>4}".format(self.score)
        pyxel.text(5, 4, s, 2)
        pyxel.text(4, 4, s, 7)
App()
